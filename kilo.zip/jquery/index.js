
$(document).ready(function(){
    $(".mobnav").click(function(){
        $(".mobnav").toggleClass('clicked');
    });

});